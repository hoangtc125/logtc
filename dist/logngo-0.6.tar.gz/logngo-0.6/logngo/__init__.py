from .main import Logger, context
from .socket import socket_ngo